<template>
    <div>
        #[[$END$]]#
    </div>
</template>

<script>
export default {}
</script>

<style scoped lang="scss">

</style>